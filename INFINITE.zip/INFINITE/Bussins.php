<?php


class Bussins
{
//LOAD
static function Load(){
    require_once "DataAccses.php" ;

}




//VALUES .....

//ONVAL : CHEK ON VAL 1
static function ONVAL($VAL1 , $VAL2){
    $VALTYPE1 = gettype($VAL1) ;
    $VALTYPE2 = gettype($VAL2) ;

    if ($VALTYPE1 != $VALTYPE2){
        return array("TYPE ERROR TYPES ARE NOT THE SAME : EXPLORER INFINITE ERROR 415" , 415 , false , "NO DATA : EXPLORER INFINITE ERROR 825 ") ;


    }
    else{
        if ($VALTYPE2 == "string"){
            $VALCOUNT1 = count($VAL1);
            $VALCOUNT2 = count($VAL2);

            $Res = $VALCOUNT1 >= $VALCOUNT2 ;
            return array("OK : EXPLORER INFINITE " , 1111 , $Res , $Res) ;

        }
        elseif ($VALTYPE1 == "array"){
            $VALCOUNT1 = count($VAL1);
            $VALCOUNT2 = count($VAL2);

            $Res = $VALCOUNT1 > $VALCOUNT2 ;
            return array("OK : EXPLORER INFINITE " , 1111 , $Res , $Res) ;


        }
        elseif ( ($VALTYPE2 == "integer" || $VALTYPE2 == "double") && ($VALTYPE1 == "integer" || $VALTYPE1 == "double")){
            $Res = $VAL1 > $VAL2 ;
            return array("OK : EXPLORER INFINITE " , 1111 , $Res , $Res) ;
        }



    }


}

//ONVALS : RETURN ARRAY
static function ONVALS($VAL1 , $VALS){
    if (gettype($VALS) != "array"){
        return array("TYPE ERROR TYPES ARE NOT THE SAME : EXPLORER INFINITE ERROR 415 " , 415 , false , false) ;
    }
    else{
        try {
            $Res = array();
            foreach ($VALS as $Val){
                if ($VAL1 >= $Val){
                    array_push($Res , true) ;

                }
                else{
                    array_push($Res , false) ;
                }
            }

            return array("OK : EXPLORER INFINITE "  , 1111 , true , $Res) ;



        }
        catch (Exception $EXP){
            return array("TYPE ERROR TYPES ARE NOT THE SAME : EXPLORER INFINITE ERROR 415 " , 415 , false , false) ;

        }
    }

}

//ONALLVALS : CHEK ON ALL VALS
static function ONALLVALS($VAL ,  $VALS){
    if (gettype($VALS) != "array" ){
        return array("TYPE ERROR TYPES ARE NOT THE SAME : EXPLORER INFINITE ERROR 415 " , 415 , false , false) ;
    }
    else{
        try {
            $Res = true ;
            foreach ($VALS as $Value){
                if ($Value > $VAL){
                    $Res = false ;
                    return array("OK : EXPLORER INFINITE " , 2222 , $Res , false) ;



                }

            }
            return array("OK : EXPLORER INFINITE " , 1111 , $Res , true ) ;


        }
        catch (Exception $EXP){
            return array("TYPE ERROR TYPES ARE NOT THE SAME : EXPLORER INFINITE ERROR 415 " , 415 , false , false) ;
        }
    }
}

//DOWNALLVALS : CHEK DOWN ALL VALS
    static function DOWNALLVALS($VAL ,  $VALS){
        if (gettype($VALS) != "array" ){
            return array("TYPE ERROR TYPES ARE NOT THE SAME : EXPLORER INFINITE ERROR 415 " , 415 , false , false) ;
        }
        else{
            try {
                $Res = true ;
                foreach ($VALS as $Value){
                    if ($Value < $VAL){
                        $Res = false ;
                        return array("OK : EXPLORER INFINITE " , 2222 , $Res , false) ;




                    }

                }
                return array("OK : EXPLORER INFINITE " , 1111 , $Res , true ) ;


            }
            catch (Exception $EXP){
                return array("TYPE ERROR TYPES ARE NOT THE SAME : EXPLORER INFINITE ERROR 415 " , 415 , false, false) ;
            }
        }
    }

//Down Value
    static function DOWNVAL($VAL1 , $VAL2){
        $VALTYPE1 = gettype($VAL1) ;
        $VALTYPE2 = gettype($VAL2) ;

        if ($VALTYPE1 != $VALTYPE2){
            return array("TYPE ERROR TYPES ARE NOT THE SAME : EXPLORER INFINITE ERROR 415" , 415 , false ,  "NO DATA : EXPLORER INFINITE ERROR 825 ") ;


        }
        else{
            if ($VALTYPE2 == "string"){
                $VALCOUNT1 = count($VAL1);
                $VALCOUNT2 = count($VAL2);

                $Res = $VALCOUNT1 <= $VALCOUNT2 ;
                return array("OK : EXPLORER INFINITE " , 1111 , $Res , $Res) ;

            }
            elseif ($VALTYPE1 == "array"){
                $VALCOUNT1 = count($VAL1);
                $VALCOUNT2 = count($VAL2);

                $Res = $VALCOUNT1 < $VALCOUNT2 ;
                return array("OK : EXPLORER INFINITE " , 1111 , $Res , $Res) ;


            }
            elseif ( ($VALTYPE2 == "integer" || $VALTYPE2 == "double") && ($VALTYPE1 == "integer" || $VALTYPE1 == "double")){
                $Res = $VAL1 < $VAL2 ;
                return array("OK : EXPLORER INFINITE " , 1111 , $Res , $Res) ;
            }



        }


    }

    //DWON VALUS
    static function DOWNVALS($VAL1 , $VALS){
        if (gettype($VALS) != "array"){
            return array("TYPE ERROR TYPES ARE NOT THE SAME : EXPLORER INFINITE ERROR 415 " , 415 , false , false) ;
        }
        else{
            try {
                $Res = array();
                foreach ($VALS as $Val){
                    if ($VAL1 <= $Val){
                        array_push($Res , true) ;

                    }
                    else{
                        array_push($Res , false) ;
                    }
                }

                return array("OK : EXPLORER INFINITE "  , 1111 , true , $Res) ;



            }
            catch (Exception $EXP){
                return array("TYPE ERROR TYPES ARE NOT THE SAME : EXPLORER INFINITE ERROR 415 " , 415 , false ,  false) ;

            }
        }

    }




//IF ....

//IFFUNCTION : RUN IF TRUE
static function IFFUNCTION($FUNCTION , $CONDITION ){
    if ($CONDITION){
        $Res = $FUNCTION();
        return array("RUNED : EXPLORER INFINITE " , 1111 , true , $Res ) ;


        }
    else{
        return array("NOT RUNED : EXPLORER INFINITE "  , 2222 , false , false) ;

    }

}

//ELSEFUNCTION : RUN IF FALSE
static function ELSEFUNCTION($FUNCTION , $CONDITION){
    if (!$CONDITION){
        $Res = $FUNCTION() ;
        return array("RUNED : EXPLORER INFINITE " , 1111 , true , $Res) ;


    }
    else{
        return array("NOT RUNED : EXPLORER INFINITE " , 2222 , false , false , false) ;

    }
}

//ARRAY

//TO ARRAY : CRATE ARRAY OF INDEX OF BEFORE ARRAY
static function ITEMINARRAY($ARRAY , $INDEX){
    if (gettype($ARRAY) != "array" ){
        return array("TYPE ERROR TYPES ARE NOT THE SAME : EXPLORER INFINITE ERROR 415 " , 415 , false , false) ;
    }
    else{
        $Res = array() ;
        foreach ($ARRAY as $AR){
            array_push($Res , $AR[$INDEX]) ;

        }
        return array("OK : EXPLORER INFINITE " , 1111 , true , $Res) ;


    }

}
//SORT : SORT ARRAY BY VALUES
static function SORT($ARRAY , $SORTBY ){

    if (gettype($ARRAY) != "array"){
        return array("TYPE ERROR TYPES ARE NOT THE SAME : EXPLORER INFINITE ERROR 415 " , 415 , false , false) ;
    }
    else{
        if ($SORTBY == 2 ){
            asort($ARRAY);
            return array("OK : EXPLORER INFINITE " , 1111 , true , $ARRAY );

        }
        elseif ($SORTBY == 1 ){
            arsort($ARRAY);
            return array("OK : EXPLORER INFINITE " , 1111 , true , $ARRAY );
        }


    }
}

//CREATE ARRAY : CREATE ARRAY WITH YOUR INDEX
static function CREATEARRAY($INDEX , $VALUES){
    if (gettype($INDEX) != "array" || gettype($VALUES) == "array"){
        $COUNT_INDEX = count($INDEX) ;
        $COUNT_VALUES = count($VALUES) ;
        if ($COUNT_INDEX != $COUNT_VALUES){
            return array("INDEX ERROR : EXPLORER INFINITE ERROR 418" , 418 , false , false) ;
        }
        else{
            $Res = array();
            for ($i=0 ; $i < $COUNT_VALUES ; $i++){
                $VAL = $VALUES[$i];
                $IN = $INDEX[$i] ;

                $Res[$IN] = $VAL ;





            }
            return array("OK : EXPLORER INFINITE " , 1111 , true , $Res) ;

        }
    }
    else{
        return array("TYPE ERROR TYPES ARE NOT THE SAME : EXPLORER INFINITE ERROR 415 " , 415 , false , false) ;
    }


}

static function INONEHUNDRED($ARRAY , $INDEX){
    if (gettype($ARRAY != "array"))
    {
        return array("TYPE ERROR TYPES ARE NOT THE SAME : EXPLORER INFINITE ERROR 415 " , 415 , false , false) ;

    }
    else{
        $COUNTITEMS = count($ARRAY) ; 
        $NUM = 0 ; 
        foreach($ARRAY as $ITEM){
            if ($ITEM == $INDEX ){
                $NUM += 1  ; 

            }
        }

        $NUMBER = 100 / $COUNTITEMS ; 
        $NUMBER2 = $NUM * $NUMBER ; 
        return array("OK : EXPLORER INFINITE " , 1111 , true , $NUMBER2) ; 
        
    }
}
//ISEXIST
static function ISEXIST($ARRAY , $INDEX){
    foreach ($ARRAY as $Item){
        if ($Item == $INDEX){
            return array("OK : EXPLORER INFINITE" , 1111 , true , true ) ;
        }
    }
    return array("OK : EXPLORER INFINITE" , 2222 , false , false ) ;
}

//CHEKUSER
static function ChekAccses($TABLENAME , $CONDITION , $RECORDCONDITION){
    $Res = DataAccses::SELECTITEM($TABLENAME , '*' , $CONDITION[0] , "$RECORDCONDITION" )[3] ;
    if ($CONDITION[1] == "="){
        if ($Res == $CONDITION[2]){
            return array("OK : EXPLORER INFINITE " , 1111 , true , true);
        }
        else{
            return array("OK : EXPLORER INFINITE " , 2222 , true , false);
        }

    }
    elseif ($CONDITION[1] == ">"){
        if ($Res > $CONDITION[2]){
            return array("OK : EXPLORER INFINITE " , 1111 , true , true);
        }
        else{
            return array("OK : EXPLORER INFINITE " , 2222 , true , false);
        }
    }
    elseif ($CONDITION[1] == "<"){
        if ($Res < $CONDITION[2]){
            return array("OK : EXPLORER INFINITE " , 1111 , true , true);
        }
        else{
            return array("OK : EXPLORER INFINITE " , 2222 , true , false);
        }
    }
    elseif ($CONDITION[1] == "!="){
        if ($Res != $CONDITION[2]){
            return array("OK : EXPLORER INFINITE " , 1111 , true , true);
        }
        else{
            return array("OK : EXPLORER INFINITE " , 2222 , true , false);
        }
    }
}

}




?>