<?php


class Scripts
{
static function MESSAGE($MESSAGE){
    echo "<script>alert('$MESSAGE');</script>";

}
static function AELEM($HREF ,  $TEXT , $COLOR ,  $CLASS , $ID , $INELEM = ' '){
    echo "<a id=$ID class=$CLASS  href=$HREF style='color:$COLOR '>$TEXT  $INELEM</a>";

}
static  function PROMPT($TEXT , $CHEKVAL , $ANSWER = '' )
{
    $Res = false  ;
    echo "<script src='SCRIPTS/SCRIPT1.js'></script>" ;


    echo "<script>var Answer = prompt( '$TEXT' , '$ANSWER' ,) ; window.location = 'login.php?Res='+Answer+'&AN='+$CHEKVAL ;  </script>" ;
    return array("OK : EXPLORER INFINITE" , 1111 , true , 'NO DATA') ;
}
static function Redirect($Address){
    echo "<script>window.location = '$Address' </script>" ;
    return array('OK : EXPLORER INFINITE' , 1111 , true , true ) ;

}
static function LOG($TEXT){
    echo "<script>console.log($TEXT)</script>" ;
    return array('OK : EXPLORER INFINITE' , 1111 , true , true ) ;
}
static function GOBACK(){
    echo "<script>window.location.history.back();</script>";
}
}

