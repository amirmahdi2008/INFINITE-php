<?php
class Files {
    static function UPLOADIMAGE($FILESIZE , $PATH ){

        $EGID = $_SESSION['EGID'] ;

        $fileDir = $PATH ;




        $fileName= $fileDir. basename($_FILES['fileToUpload']['name']);
        $uploadOk= 1;

        $fileType= pathinfo($fileName, PATHINFO_EXTENSION);
        $FileName = pathinfo($fileName, PATHINFO_FILENAME);

        if (isset($_POST['submit'])) {

            // check not empty file name.
            if (empty(basename($_FILES['fileToUpload']['name']))) {

                $uploadOk= 0;
            }
            else {
                $FileSize = $_FILES['fileToUpload']['size'] ;
                //Check file size:
                if ($_FILES['fileToUpload']['size'] > 600000) {

                    Scripts::MESSAGE('حجم فایل زیاد است عکس دیگری را انتخاب کنید');
                    $uploadOk= 0;
                }
                //check existing file
                if (file_exists($fileName)) {
                    Scripts::MESSAGE('چنین فایلی وجود دارد نام این را تغیر دهید');
                    $uploadOk= 0;
                }
                //check image- an actual image or fake
                $check= getimagesize($_FILES['fileToUpload']['tmp_name']);
                //if actual image:
                if ($check !== false) {
                    //check file extensions: you can select only (jpg, jpeg, png, gif) file
                    if ($fileType != 'jpg' && $fileType != 'jpeg' && $fileType != 'png' && $fileType != 'gif') {
                        Scripts::MESSAGE('پسوند انتخاب شده مجاز نیست پسوند های مجاز :jpg, jpeg, png, gif');
                        $uploadOk= 0;
                    }
                }
                //if fake image:
                else {
                    Scripts::MESSAGE('فایلی که انتخاب کرده اید عکس نیست');
                    $uploadOk= 0;
                }
            }
            //check $uploadok variable
            if ($uploadOk !== 0) {
                if (move_uploaded_file($_FILES['fileToUpload']['tmp_name'], $fileName)) {
                    $NowDate = jdate("Y-m-d-H-i-s-");
                    $Res = DataAccses::INSERT('files' , array('FileName' , 'SaveAddress' , 'CreateAt' , 'DownloadNumber' , 'EGID' , 'FileSize') , array($FileName.$fileType ,$fileName , $NowDate , 0 , $EGID , $FileSize )) ;
return array('EXPLORER INFINITE : OK ' , 1111 , true , array($FileName , $FileSize , $fileType , $fileName , $NowDate)) ;


                }
                else {
                    Scripts::MESSAGE('هنگام بارگزاری خطایی رخ داد دوباره تلاش کنید');
                    $uploadOk= 0;
                }

            }
            //If Error, show 'Go back' link
            else {

            }
        }}

}