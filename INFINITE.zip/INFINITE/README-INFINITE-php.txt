This is a free and open source library that you can download and use for free and easily.
The activities of these libraries are as follows:
1. Connect to the database and execute many database commands simply
2. Collect code that you normally use a lot and make your code cluttered
3. Some JavaScript code is collected in these libraries
And ...

Use of these libraries is free and you can easily use them. These libraries are open source and free so that we can help the open source community as much as possible.
If you have enough knowledge in this field, you can edit the core of this library and use it. If you are a member of the open source community or you want to become a member, give us the version you have edited. Send it to explorerinfinitephp@gmail.ir or infinite@oflink.ir. In the next versions, your name will definitely be one of the influential people in development.

More :
The website of educational documents is oflink.ir/infinite. It should also be mentioned that if this address is changed, the same address will be redirected to the new address.


All Rights Reversed | CopyRight 2021 | EXPLORER Inc