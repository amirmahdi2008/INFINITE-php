<?php

class DB {
     static function Connection()
    {
        require_once "DatabaseDB.php" ; // For Connect To Database
        $ConnectData = DatabaseDB::Connect() ; // Data Of Connect To MYSQL

        $DatabaseName = $ConnectData[0]; // Name Of Database
        $Username = $ConnectData[1]; // Username of Database
        $Password = $ConnectData[2]; //Password of Database
        try {
            $Connection = new PDO('mysql:host' . 'localhost' . ';dbname=' . $DatabaseName, $Username, $Password);
            $Connection->exec("SET NAMES utf8");
            $Connection->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            return array($Connection, $DatabaseName, true , $Connection);
        }


        catch (PDOException $Exeption) {
            return array( "Connection Faild : EXPLORER INFINITE 316" , 316 , false , false) ;


        }
    }
}
class DataAccses
{
    //DATABASE LOAD FUNCTION
    static function Load(){

        $Result = DB::Connection() ;
        if ($Result == false){
            return array( "Connection Faild : EXPLORER INFINTE ERROR 315" , 315 , false);

        }
        else{
            //Index 0 = Connection and index 1 = Databasename
            return array($Result[0] , $Result[1] , true) ;

        }





    }


    //INSERT FUNCTION
    static function INSERT($TableName  , $PARAMETRS , $VALUES ){
        $Result = self::Load() ;
        
        if ($Result[2] != false){
            //Name of Database And Save Connection
            $Databasename = $Result[1] ;
            $Connection = $Result[0] ;

            //Count Items In Parametrs List
            $Num1 = 0 ;
            $Count1 = count($PARAMETRS)                                                ;

            //Count Items In Values List
            $Num2 = 0 ;
            $Count2 = count($VALUES) ;



            //Create SQL TEXT

            $SQLINSERT = "INSERT INTO " ;
            $SQLINSERT.= $Databasename ;
            $SQLINSERT.="." ;
            $SQLINSERT.="$TableName" ;
            $SQLINSERT.="(" ;





            foreach ($PARAMETRS as $PARAM){
                $Num1+=1 ;



                $SQLINSERT.=$PARAM ;
                $SQLINSERT.=" ";
                if ($Num1 != $Count1){
                    $SQLINSERT.=", ";
                }



            }
            $SQLINSERT.=")" ;
            $SQLINSERT.=" VALUES (" ;
            foreach ($VALUES as $PARAM){
                $Num2+=1 ;

                $SQLINSERT.="'$PARAM'" ;
                $SQLINSERT.=" ";
                if ($Num2 != $Count2){
                    $SQLINSERT.=", ";
                }


            }
            $SQLINSERT.=") ; " ;

            //INSERT TO DATABASE
           try {
               $Res = $Connection->exec($SQLINSERT);
               return array("INSERTED : EXPLORER INFINITE " , 1111 , true , $Res ) ;
           }
           catch (Exception $EXP){
               //THE ERROR
               
               return array("YOU HAVE AN ERROR IN SQL SYNTAX OR PARAMETRS : EXPLORER INFINITE ERROR 317" , 317 , false) ;

           }

        }

    }

    //QUERY FUNCTION
    static function QUERY($QUERY){
        $Result = self::Load() ;
        
        if ($Result[2] != false) {
            //Database Name and Save Connection
            $Connection = $Result[0];
            $Databasename = $Result[1];

            try {
                //Send Data To SERVER
                $Res =  $Connection->query($QUERY);
                return array("OK ! : EXPLORER INFINITE " , 1111 , true , $Res );

            } catch (Exception $EXP) {
                //ERROR
                return array("YOU HAVE AN ERROR IN SQL SYNTAX OR PARAMETRS : EXPLORER INFINITE ERROR 317", 317, false);
            }


        }


    }

    //DELETE
    static function DELETE($TABLENAME , $CONDITION = " " ){
        $Result = self::Load() ;
        
        if ($Result[2] != false){
            //Database Name and Save Connection
            $Connection = $Result[0] ;
            $Databasename = $Result[1] ;

            //Create SQL TEXT FOR DELETE

            $SQLDELETE = "DELETE FROM " ;
            $SQLDELETE.= "$Databasename" ;
            $SQLDELETE.= ".";
            $SQLDELETE.= "$TABLENAME " ;

            if ($CONDITION != " "){ // CHEK CONDITION
                $SQLDELETE.="WHERE $CONDITION" ;

            }

            try {
                //DELETE IN TO TABLE
                $Res = $Connection->exec($SQLDELETE) ;

                return array("DELETED : EXPLORER INFINITE " , 1111 , true , $Res)  ;

            }
            catch (Exception $EXP){
                //ERROR
                return array("YOU HAVE AN ERROR IN SQL SYNTAX OR PARAMETRS : EXPLORER INFINITE ERROR 317" , 317 , false) ;
            }





        }
    }


    //UPDATE
    static function UPDATE($TABLENAME , $SETVALUES , $CONDITION = " "){
        $Result = self::Load() ;
        
        if ($Result[2] != false)
            //Database Name and Save Connection
            $Connection = $Result[0];
            $Databasename = $Result[1];

            //CREATE SQL TEXT
            $SQLUPDATE = "UPDATE $Databasename" ;
            $SQLUPDATE.="." ;
            $SQLUPDATE.="$TABLENAME SET $SETVALUES " ;
            if ($CONDITION != " "){ //CHEK CONDITION
                $SQLUPDATE.="WHERE $CONDITION" ;

            }

            try{
                //UPDATE TABLE
                $Res = $Connection->exec($SQLUPDATE) ;
                return array("UPDATED : EXPLORER INFINITE " , 1111 , true , $Res)  ;



            }
            catch (Exception $EXP){
                return array("YOU HAVE AN ERROR IN SQL SYNTAX OR PARAMETRS : EXPLORER INFINITE ERROR 317" , 317 , false , $EXP) ;

            }




        }

        //SELECT
        static function SELECT($TABLENAME , $SELECTITEMS , $CONDITION = " " ){

            $Result = self::Load() ;

            if ($Result[2] != false){
                //Database Name and Save Connection
                $Connection = $Result[0];
                $Databasename = $Result[1];

                //CREATE SQL TEXT
                $SQLSELECT = "SELECT $SELECTITEMS FROM $Databasename" ;
                $SQLSELECT.=".";
                $SQLSELECT.="$TABLENAME" ;

                if ($CONDITION != " "){
                    $SQLSELECT.=" WHERE " ;
                    $SQLSELECT.=$CONDITION ;

                }

                try {

                   $Query = $Connection->prepare($SQLSELECT);
                   $Query->execute();
                   $Res = $Query->fetchAll() ;

                    //RESULT OF QUERY IN INDEX 3

                    return array("SELECTED : EXPLORER INFINITE " , 1111 , true , $Res) ;


                }
                catch (Exception $EXP){
                    //ERROR
                    return array("YOU HAVE AN ERROR IN SQL SYNTAX OR PARAMETRS : EXPLORER INFINITE ERROR 317" , 317 , false , $EXP) ;


                }
            }

        }


        //Create Table
        static function CREATETABLE($TABLENAME ,$COLUMN , $PROPERTY){
        $Result = self::Load() ;

            if ($Result[2] != false) {
                //Database Name and Save Connection
                $Connection = $Result[0];
                $Databasename = $Result[1];


                if (count($COLUMN) != count($PROPERTY)){
                    return array("YOU HAVE AN ERROR IN SQL SYNTAX OR PARAMETRS : EXPLORER INFINITE ERROR 317" , 317 , false) ;


                }
                else{
                    //CRAETE SQL TEXT
                    $SQLCREATE = "CREATED TABLE $Databasename";
                    $SQLCREATE.=".";
                    $SQLCREATE.="$TABLENAME (" ;

                    for($i= 0 ; $i < count($PROPERTY) ; $i++){
                        $SQLCREATE.= " $COLUMN[$i] " ;
                        $SQLCREATE.= " $PROPERTY[$i]" ;

                        if ($i != count($COLUMN)){
                            $SQLCREATE.=")";

                        }
                        $SQLCREATE.=";" ;


                    }
                    try {
                        $Connection->exec($SQLCREATE) ;
                        return array("CREATED : EXPLORER INFINITE " , 1111 , true) ;

                    }
                    catch (Exception $EXP){
                        //ERROR
                        return array("YOU HAVE AN ERROR IN SQL SYNTAX OR PARAMETRS : EXPLORER INFINITE ERROR 317" , 317 , false) ;
                    }

                }
            }


        }

//ISEXIST : CHEK EXIST IN DATABASE
        static function ISEXIST($TABLENAME , $CONDITION){
        try {
            self::Load() ;
            $RES_ARRAY = self::SELECT($TABLENAME , '*') ;

            $RES_ARRAY = $RES_ARRAY[3];



            foreach ($RES_ARRAY as $Res ){
                $Num = 0 ;
                foreach ($CONDITION as $CONDI){
                    if ($CONDI[1] == "="){

                        if ($Res[$CONDI[0]] == $CONDI[2] ){

                            $Num += 1 ;

//                            return array("OK : EXPLORER INFINITE" , 1111 , true ,  $Res);

                        }
//                        else{
//                            return array("OK : EXPLORER INFINITE" , 2222 , false ,  $Res);
//                        }


                    }
                    elseif ($CONDI[1] == ">"){
                        if ($Res[$CONDI[0]] > $CONDI[2] ){
                            $Num += 1 ;
//                            return array("OK : EXPLORER INFINITE" , 1111 , true ,  $Res);

                        }
//                        else{
//                            return array("OK : EXPLORER INFINITE" , 2222 , false ,  $Res);
//                        }


                    }

                    elseif ($CONDI[1] == "<"){
                        if ($Res[$CONDI[0]] < $CONDI[2] ){
                            $Num += 1 ;
//                            return array("OK : EXPLORER INFINITE" , 1111 , true ,  $Res);

                        }
//                        else{
//                            return array("OK : EXPLORER INFINITE" , 2222 ,false ,  $Res);
//                        }


                    }

                    elseif ($CONDI[1] == ">="){
                        if ($Res[$CONDI[0]] >= $CONDI[2] ){
                            $Num += 1 ;
//                            return array("OK : EXPLORER INFINITE" , 1111 , true ,  $Res);

                        }
//                        else{
//                            return array("OK : EXPLORER INFINITE" , 2222 , false ,  $Res);
//                        }


                    }
                    elseif ($CONDI[1] == "<="){
                        if ($Res[$CONDI[0]] <= $CONDI[2] ){
                            $Num += 1 ;
//                            return array("OK : EXPLORER INFINITE" , 1111 , true ,  $Res);

                        }
//                        else{
//                            return array("OK : EXPLORER INFINITE" , 2222 , false ,  $Res);
//                        }


                    }
                    else{
                        return array("OPERATOR NOT FOUND : EXPPLORER INFINITE " , 318 , false , false) ;

                    }

                }
                if (count($CONDITION ) == $Num){
                    return array("OK : EXPLORER INFINITE" , 1111 , true ,  $Res);
                }
            }
            return array("OK : EXPLORER INFINITE" , 2222 , false ,false);
        }
        catch (Exception $EXP){
            return array("SYNTAX ERROR : EXPLORER INFINITE " , 652 , false , false) ;

        }



        }
//SELECT ITEM : SELECT ITEM FROM FETCH ARRAY AND RETURN TO USER
        static function SELECTITEM($TABLENAME , $SELECTITEMS , $INDEX  , $CONDITION  )
        {
            $Result = self::Load() ;

            if ($Result[2] != false){
                //Database Name and Save Connection
                $Connection = $Result[0];
                $Databasename = $Result[1];

                //CREATE SQL TEXT
                $SQLSELECT = "SELECT $SELECTITEMS FROM $Databasename" ;
                $SQLSELECT.=".";
                $SQLSELECT.="$TABLENAME" ;

                if ($CONDITION != " "){
                    $SQLSELECT.=" WHERE " ;
                    $SQLSELECT.=$CONDITION ;

                }

                try {


                    $Query = $Connection->prepare($SQLSELECT);
                    $Query->execute();
                    $Res = $Query->fetch();
                    //RESULT OF QUERY IN INDEX 3
                    $ResItem = $Res[$INDEX] ;



                    return array("SELECTED ITEM  : EXPLORER INFINITE " , 1111 , true , $ResItem) ;


                }
                catch (Exception $EXP){
                    //ERROR
                    return array("YOU HAVE AN ERROR IN SQL SYNTAX OR PARAMETRS : EXPLORER INFINITE ERROR 317" , 317 , false) ;


                }
            }
        }

        //SELECT ITEMS : SELECT ITEM FROM FETCH ALL ARRAY
    static function SELECTITEMS($TABLENAME , $SELECTITEMS , $INDEX  , $CONDITION = " " )
    {
        $Result = self::Load() ;

        if ($Result[2] != false){
            //Database Name and Save Connection
            $Connection = $Result[0];
            $Databasename = $Result[1];

            //CREATE SQL TEXT
            $SQLSELECT = "SELECT $SELECTITEMS FROM $Databasename" ;
            $SQLSELECT.=".";
            $SQLSELECT.="$TABLENAME" ;

            if ($CONDITION != " "){
                $SQLSELECT.=" WHERE " ;
                $SQLSELECT.=$CONDITION ;

            }

            try {
                $Query = $Connection->prepare($SQLSELECT);
                $Query->execute();
                $Res = $Query->fetchAll();
                //RESULT OF QUERY IN INDEX 3
$ResArray = array() ;
foreach ($Res as $re){
    array_push($ResArray , $re[$INDEX]) ;
}
                return array("SELECTED ITEMs  : EXPLORER INFINITE " , 1111 , true , $ResArray) ;
            }
            catch (Exception $EXP){
                //ERROR
                return array("YOU HAVE AN ERROR IN SQL SYNTAX OR PARAMETRS : EXPLORER INFINITE ERROR 317" , 317 , false) ;
            }
        }
    }

    static function FETCHITEM($TABLENAME , $SELECTITEMS , $CONDITION = " "){
        $Result = self::Load() ;

        if ($Result[2] != false){
            //Database Name and Save Connection
            $Connection = $Result[0];
            $Databasename = $Result[1];

            //CREATE SQL TEXT
            $SQLSELECT = "SELECT $SELECTITEMS FROM $Databasename" ;
            $SQLSELECT.=".";
            $SQLSELECT.="$TABLENAME" ;

            if ($CONDITION != " "){
                $SQLSELECT.=" WHERE " ;
                $SQLSELECT.=$CONDITION ;

            }

            try {


                $Query = $Connection->prepare($SQLSELECT);
                $Query->execute();
                $Res = $Query->fetch();




                return array("SELECTED ITEM  : EXPLORER INFINITE " , 1111 , true , $Res) ;


            }
            catch (Exception $EXP){
                //ERROR
                return array("YOU HAVE AN ERROR IN SQL SYNTAX OR PARAMETRS : EXPLORER INFINITE ERROR 317" , 317 , false) ;


            }
        }
    }
    static function SELECTONE($TABLENAME , $INDEX , $CONDITION){
        $Result = self::Load() ;

        if ($Result[2] != false){
            //Database Name and Save Connection
            $Connection = $Result[0];
            $Databasename = $Result[1];

            //CREATE SQL TEXT
            $SQLSELECT = "SELECT * FROM $Databasename" ;
            $SQLSELECT.=".";
            $SQLSELECT.="$TABLENAME" ;

            if ($CONDITION != " "){
                $SQLSELECT.=" WHERE " ;
                $SQLSELECT.=$CONDITION ;

            }

            try {


                $Query = $Connection->prepare($SQLSELECT);
                $Query->execute();
                $Res = $Query->fetch();
                $Res2 = $Res[$INDEX] ;





                return array("SELECTED ITEM  : EXPLORER INFINITE " , 1111 , true , $Res2) ;


            }
            catch (Exception $EXP){
                //ERROR
                return array("YOU HAVE AN ERROR IN SQL SYNTAX OR PARAMETRS : EXPLORER INFINITE ERROR 317" , 317 , false) ;


            }
        }
    }






}


?>
